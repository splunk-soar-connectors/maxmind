# pylint:disable=C0111

__title__ = "geoip2"
__version__ = "4.8.0"
__author__ = "Gregory Oschwald"
__license__ = "Apache License, Version 2.0"
__copyright__ = "Copyright (c) 2013-2023 MaxMind, Inc."
